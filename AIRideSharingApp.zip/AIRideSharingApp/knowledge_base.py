from pathlib import Path
import streamlit as st
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from llm_client import embedding_model
from config import KB_DIR

def load_knowledge_base():
    kb_path = Path(KB_DIR)
    if not kb_path.exists():
        st.error("⚠️ 'kb' folder not found.")
        st.stop()
    docs = []
    for file in kb_path.glob("ride_faq_*.txt"):
        with open(file, "r", encoding="utf-8") as f:
            docs.append(f.read())
            print("I am injecting")
    return "\n\n".join(docs)

def build_vector_db():
    raw_text = load_knowledge_base()
    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = splitter.split_text(raw_text)
    vectordb = Chroma.from_texts(chunks, embedding_model, persist_directory="./chroma_index")
    vectordb.persist()
    return vectordb
