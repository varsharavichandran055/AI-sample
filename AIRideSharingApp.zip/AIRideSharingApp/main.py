import streamlit as st
# from rag_chain import rag_chain
from llm_client import llm
from langchain_core.messages import HumanMessage,AIMessage
from utils import detect_language_name
from config import SUPPORTED_LANGUAGES
from agent import translate_agent
from rag_chain import getcontext
st.set_page_config(page_title="🚗 AI Ride-Sharing Assistant", layout="centered")
st.title("🚘 AI Ride-Sharing Communication Assistant")
st.markdown("Ask questions in English, Spanish, or French. Responses will be in the same language.")
st.info(f"🌐 Supported languages: {', '.join(SUPPORTED_LANGUAGES)}")

# Initialize chat history
if "history" not in st.session_state:
    st.session_state.history = []

# User input
query = st.text_input("💬 Ask your assistant:", placeholder="Ask about your cab, location...")

if query:
    detected_language = detect_language_name(query)

    with st.spinner(f"Detected language: {detected_language}. Processing..."):

        retrievedContext = getcontext(query)
        agent_response=translate_agent.invoke({"messages":[HumanMessage(content=retrievedContext),HumanMessage(content=query)]})
        # answer = ""
        # source_docs = []
        print("Agents response",agent_response)
        answer=AIMessage=agent_response["messages"][-1]
    
        st.session_state.history.insert(0,(query, answer.content))

# Display chat history
for user_q, bot_a in st.session_state.history:
    st.markdown(f"**🧑 You:** {user_q}")
    st.markdown(f"**🤖 Assistant:** {bot_a}")
    st.divider()
