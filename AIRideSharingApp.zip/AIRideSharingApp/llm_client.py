import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from config import GENAI_BASE_URL, API_KEY

http_client = httpx.Client(verify=False)

# LLM client
llm = ChatOpenAI(
    base_url=GENAI_BASE_URL,
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=API_KEY,
    http_client=http_client,
)

# Embedding model
embedding_model = OpenAIEmbeddings(
    base_url=GENAI_BASE_URL,
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=API_KEY,
    http_client=http_client,
)
