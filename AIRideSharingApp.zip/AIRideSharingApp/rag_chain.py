from knowledge_base import build_vector_db
from llm_client import llm
from langchain.chains import RetrievalQA

vectordb = build_vector_db()
# retriever = vectordb.as_retriever(search_type="similarity", search_kwargs={"k": 4})
def getcontext(query:str):
    results= vectordb.similarity_search(query,k=5)
    context= "\n".join([r.page_content for r in results])
    return context
