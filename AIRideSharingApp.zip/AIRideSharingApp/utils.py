from langdetect import detect
from langcodes import Language
from config import SUPPORTED_LANGUAGES

def detect_language_name(text):
    try:
        code = detect(text)
        lang_name = Language.get(code).language_name()
        if lang_name in SUPPORTED_LANGUAGES:
            return lang_name
        return "English"  # fallback if unsupported
    except:
        return "English"
