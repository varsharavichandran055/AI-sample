import os

# TikToken cache
TIKTOKEN_CACHE_DIR = "C:/Users/GenAICHNSIRUSR81/Downloads/new/AIRideSharingApp/tiktoken_cache"
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR

# API and base URL
GENAI_BASE_URL = "https://genailab.tcs.in"
API_KEY = "sk-N209dbkUn55mryNORI87tg"  # Replace with actual key

# KB directory
KB_DIR = "kb"

# Supported languages
SUPPORTED_LANGUAGES = ["English", "Spanish", "French"]
