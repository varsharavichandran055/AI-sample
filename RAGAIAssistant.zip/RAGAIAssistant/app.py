import os

# Set tiktoken cache dir environment variable early (before importing LangChain/OpenAI modules)
tiktoken_cache_dir = "C:/Users/GenAICHNSIRUSR81/Documents/RAGAIAssistant/tiktoken_cache"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

# Validate the cached file exists
assert os.path.exists(os.path.join(tiktoken_cache_dir, "9b5ad71b2ce5302211f9c61530b329a4922fc6a4")), \
    "tiktoken cache file missing! Please download and place it in the cache folder."

from pathlib import Path

import httpx
import tiktoken
import streamlit as st
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.chains import RetrievalQA

# ----------------------------
# Setup & Environment
# ----------------------------


# validate
assert os.path.exists(os.path.join(tiktoken_cache_dir,"9b5ad71b2ce5302211f9c61530b329a4922fc6a4"))

# Disable SSL verification for development (unsafe for production)
http_client = httpx.Client(verify=False)

# ----------------------------
# API Configuration
# ----------------------------
GENAI_BASE_URL = "https://genailab.tcs.in"  # Replace with your internal endpoint
API_KEY = "sk-N209dbkUn55mryNORI87tg"  # Replace with your API key

# ----------------------------
# Initialize LLM and Embeddings
# ----------------------------
llm = ChatOpenAI(
    base_url=GENAI_BASE_URL,
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=API_KEY,
    http_client=http_client,
)

embedding_model = OpenAIEmbeddings(
    base_url=GENAI_BASE_URL,
    model="azure/genailab-maas-text-embedding-3-large",
    api_key=API_KEY,
    http_client=http_client,
)

# ----------------------------
# Load Knowledge Base
# ----------------------------
KB_DIR = Path("kb")

def load_knowledge_base():
    if not KB_DIR.exists():
        st.error("⚠️ No knowledge base found. Create a folder named 'kb' with .txt files.")
        st.stop()
    docs = []
    for file in KB_DIR.glob("*.txt"):
        with open(file, "r", encoding="utf-8") as f:
            docs.append(f.read())
    return "\n\n".join(docs)

# ----------------------------
# Streamlit UI Setup
# ----------------------------
st.set_page_config(page_title="Retail AI Assistant")
st.title("🛍️ Retail Customer Support AI Assistant")
st.markdown("Ask me about product details, return policies, or store information!")

# ----------------------------
# Step 1: Load & Split KB
# ----------------------------
with st.spinner("Loading knowledge base..."):
    raw_text = load_knowledge_base()
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = text_splitter.split_text(raw_text)

# ----------------------------
# Step 2: Embed and Store in Chroma
# ----------------------------
with st.spinner("Indexing knowledge base..."):
    vectordb = Chroma.from_texts(chunks, embedding_model, persist_directory="./chroma_index")
    vectordb.persist()

# ----------------------------
# Step 3: RAG QA Chain
# ----------------------------
retriever = vectordb.as_retriever(search_type="similarity", search_kwargs={"k": 4})
rag_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    return_source_documents=True
)

# ----------------------------
# Step 4: Streamlit Chat UI
# ----------------------------
if "history" not in st.session_state:
    st.session_state.history = []

query = st.text_input("💬 Ask your question:", placeholder="e.g., What is your return policy?")
if query:
    with st.spinner("Thinking..."):
        result = rag_chain.invoke(query)
        answer = result.get("result") if isinstance(result, dict) else result
        st.session_state.history.append((query, answer))

# ----------------------------
# Step 5: Display Conversation
# ----------------------------
for user_q, bot_a in st.session_state.history:
    st.markdown(f"**🧑‍💼 You:** {user_q}")
    st.markdown(f"**🤖 Assistant:** {bot_a}")
    st.divider()
